export const base_url = 'http://localhost:3000/api/v1'

export const ws_url = 'http://localhost:3000'